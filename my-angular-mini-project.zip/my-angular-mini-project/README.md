# Mini Angular Project

This is a simple Angular project showing a product list component.
